#include "UObject.h"
#include "UWorld.h"


UObject::~UObject() noexcept
{
}
